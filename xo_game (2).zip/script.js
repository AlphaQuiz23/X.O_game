let currentPlayer = "X";
let cells = document.querySelectorAll(".cell");
let board = ["", "", "", "", "", "", "", "", ""];
let gameActive = true;

cells.forEach(cell => {
  cell.addEventListener("click", () => {
    const index = cell.dataset.index;

    if (board[index] === "" && gameActive) {
      board[index] = currentPlayer;
      cell.textContent = currentPlayer;
      checkWinner();
      currentPlayer = currentPlayer === "X" ? "O" : "X";
      document.getElementById("status").textContent = "دور اللاعب: " + currentPlayer;
    }
  });
});

function checkWinner() {
  const winPatterns = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8],
    [0,4,8], [2,4,6]
  ];

  for (let pattern of winPatterns) {
    const [a,b,c] = pattern;
    if (board[a] && board[a] === board[b] && board[b] === board[c]) {
      gameActive = false;
      document.getElementById("status").textContent = "الفائز هو: " + board[a];
      return;
    }
  }

  if (!board.includes("")) {
    document.getElementById("status").textContent = "تعادل!";
    gameActive = false;
  }
}

function restartGame() {
  board = ["", "", "", "", "", "", "", "", ""];
  currentPlayer = "X";
  gameActive = true;
  document.getElementById("status").textContent = "دور اللاعب: X";
  cells.forEach(cell => cell.textContent = "");
}
